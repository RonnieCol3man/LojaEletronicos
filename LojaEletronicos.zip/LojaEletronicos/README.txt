Como executar o projeto:
- Abrir o netbeans
- Abrir o arquivo bdLojaEletronicos.sql
- Criar um banco de dados na aba servi�os no netbeans com o nome "apd3"
- Copiar o conteudo do arquivo .sql e rodar o c�digo
- Abrir na aba projetos os projetos web e aplica��o java
- Abrir o projeto web e o pacote p�ginas web
- Abrir o index.jsp e clicar em executar
- O arquivo deve carregar uma p�gina web no navegador